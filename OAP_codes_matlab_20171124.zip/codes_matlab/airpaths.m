function airpaths()

    addpath(genpath(pwd));
    
end
function save_mat(dir,name,roi)

    save(fullfile(dir,name),'roi');

end